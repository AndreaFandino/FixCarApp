package com.edu.fixcar.view.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.edu.fixcar.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_home)
    }
}